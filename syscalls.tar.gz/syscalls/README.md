

--------Q1-------------
I have divided the file into sub files with size 1000000 and read it and reversed and written in a file which is in Created folder.To create it into junks..First I taken the total chars in the file by using the lseek syscall and dividing it with the 1000000 and I run the loop of quoitent times and by taking the reaminder,separately reversed the contents and changed the pointer of written file and written into it.

-------Q2---------------

started one file from starting and another from end..If at a point if it is not equal..then it is not reersed file of one each other.